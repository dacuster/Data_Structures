#include <iostream>
#include <vector>
#include <queue>
#include "Node.h"
#include "Huffman.h"

int main()
{
	std::vector<char> data;
	std::vector<int> frequency;

	Huffman set = Huffman();

	


	return 0;
}